: initAllMotors
init-MotorRightBackward start-MotorRightBackward
init-MotorRightForward start-MotorRightForward
init-MotorLeftBackward start-MotorLeftBackward
init-MotorLeftForward start-MotorLeftForward
;

 : enableRight  
 pin import   
9 output-pin  
high 9 pin!  
;  

: disableRight
 pin import   
9 output-pin  
low 9 pin!  
;  

: enableLeft \ green left yellow
 pin import   
3 output-pin  \ gpio09
high 3 pin!  
;  

: disableLeft  
pin import
3 output-pin  
low 3 pin!  
;  

: enableAll   enableRight enableLeft ;
: disableAll disableRight disableLeft ;

 : Forward  100 MotorRightForward  100 MotorLeftForward ;
 : Backward 100 MotorRightBackward 100 MotorLeftBackward ;
 : StopForward 0 MotorRightForward  0 MotorLeftForward ;
 : StopBackward 0  MotorRightBackward  0 MotorLeftBackward ;
 : stop_motors StopForward StopBackward ; 
 : InitAll enableAll initAllmotors ;
\ applications motors

: test_motors  Forward 2000 ms stop_motors 500 ms Backward 2000 ms stop_motors ;
: start_test_motors  initAll test_motors stop_motors ;

\ FourSensors
compile-to-flash  
cornerstone -petit \ I'm using French  markers to avoid interfering with the English words
begin-module four_sensors 
 
\ initialization
pin import 4 input-pin 5 input-pin 20 input-pin 21 input-pin InitAll 
 
\ initialization straight line
: turnRight 100 MotorLeftForward 1 ms stop_motors  ;      
: turnLeft   90 MotorRightForward 2 ms stop_motors ;    
: LEFT 0 ;  : RIGHT 1 ;  : 1= 1 = ; : BOTH-OFF? AND 0= ;       
: GOSTRAIGHT turnLeft turnRight ;      
: turn ( n-- ) 0= if turnRight else turnLeft then ;     
: LEFTSENSOR 4 pin@  ;  : LEFTSIDESENSOR 28 pin@ ;    
: RIGHTSENSOR 5 pin@ ;  : RIGHTSIDESENSOR 27  pin@ ;
  
\ engine initialization
: few-steps InitAll FORWARD 400 ms stop_motors ;  \ quelques tours de roue pour pour centrer le robot sur la ligne.
: out-loop LEFTSENSOR RIGHTSENSOR and  0=  ;  
: out-loop_clockwise LEFTSENSOR 0=  ;  
: out-loop_anticlockwise RIGHTSENSOR 0= ; 
: step-clockwise 80 MotorRightForward 80 MotorLeftBackward 100 ms stop_motors ;  
: step-anticlockwise 80 MotorRightBackward 80 MotorLeftForward 100 ms stop_motors ; 
 
\ initialization of right angle rotation mode
: all-turn-clockwise begin drop step-clockwise  out-loop_clockwise until  ; \ mise en place d'un pas à pas pour le déplacement cirdulaire.       
: all-turn-anticlockwise begin  drop step-anticlockwise out-loop_anticlockwise until ;  
: run_tiny-clockwise  few-steps all-turn-clockwise  ;    
: run_tiny-anticlockwise few-steps all-turn-anticlockwise ; 

\ command on the straight line
 : tiny InitAll begin   LEFTSENSOR RIGHTSENSOR BOTH-OFF? if GOSTRAIGHT then   LEFTSENSOR turn RIGHTSENSOR turn out-loop 0= until ; 

 \ command on right angle rotation mode
: tiny-full InitAll begin   LEFTSENSOR RIGHTSENSOR BOTH-OFF? if GOSTRAIGHT then   LEFTSENSOR turn RIGHTSENSOR turn  LEFTSIDESENSOR 0= if run_tiny-anticlockwise then RIGHTSIDESENSOR 0= if run_tiny-clockwise  then  again ( out-loop 0= until ) ;  
end-module  
four_sensors::tiny-full

compile-to-flash
cornerstone -ligne
: tiny>> 4000 ms four_sensors::tiny-full four_sensors unimport ; \ launch the TinyRobot in a delayed time.
: >tiny four_sensors unimport page reboot ; \ clear overflow clearing out the wordlist




